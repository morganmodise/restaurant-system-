<?php
session_start();
include("../connection/connect.php");

error_reporting(E_ALL);
ini_set('display_errors',1);

/* ================= ADMIN PROTECTION ================= */
if(!isset($_SESSION['adm_id'])){
    header("Location:index.php");
    exit();
}

$error="";
$success="";

/* ================= ADD CATEGORY ================= */

if(isset($_POST['submit'])){

$c_name = trim($_POST['c_name']);

if($c_name==""){
$error='<div class="alert alert-danger">Category name required!</div>';
}
else{

/* CHECK EXISTING CATEGORY */

$stmt = $db->prepare("SELECT c_id FROM res_category WHERE c_name=?");
$stmt->bind_param("s",$c_name);
$stmt->execute();
$stmt->store_result();

if($stmt->num_rows>0){
$error='<div class="alert alert-danger">Category already exists!</div>';
}
else{

/* INSERT CATEGORY */

$insert=$db->prepare("INSERT INTO res_category(c_name,date) VALUES(?,NOW())");
$insert->bind_param("s",$c_name);

if($insert->execute()){
$success='<div class="alert alert-success">New Category Added Successfully.</div>';
}else{
$error='<div class="alert alert-danger">Database Error!</div>';
}

}
}
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">

<title>Add Category</title>

<link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">

<style>

body{
background:#f4f6f9;
font-family:Segoe UI;
}

.card{
border-radius:14px;
box-shadow:0 5px 25px rgba(0,0,0,.08);
}

.card-header{
background:#ff6600;
color:#fff;
font-weight:bold;
}

.btn-primary{
background:#ff6600;
border:none;
}

.btn-primary:hover{
background:#e65c00;
}

table{
background:#fff;
}

</style>
</head>

<body>

<div class="container mt-4">

<?= $error ?>
<?= $success ?>

<div class="card mb-4">
<div class="card-header">Add Restaurant Category</div>

<div class="card-body">

<form method="post">

<div class="form-group">
<label>Category Name</label>
<input type="text" name="c_name" class="form-control" required>
</div>

<button type="submit" name="submit" class="btn btn-primary">
Save Category
</button>

<a href="dashboard.php" class="btn btn-secondary">
Back
</a>

</form>

</div>
</div>

<!-- ================= CATEGORY LIST ================= -->

<div class="card">

<div class="card-header">Listed Categories</div>

<div class="card-body">

<div class="table-responsive">

<table class="table table-bordered table-hover">

<thead class="thead-dark">
<tr>
<th>ID</th>
<th>Category</th>
<th>Date</th>
<th>Action</th>
</tr>
</thead>

<tbody>

<?php

$result=$db->query("SELECT * FROM res_category ORDER BY c_id DESC");

if($result->num_rows==0){
echo "<tr><td colspan='4' class='text-center'>No Categories Found</td></tr>";
}
else{

while($row=$result->fetch_assoc()){

echo "
<tr>
<td>{$row['c_id']}</td>
<td>{$row['c_name']}</td>
<td>{$row['date']}</td>
<td>

<a href='update_category.php?cat_upd={$row['c_id']}'
class='btn btn-info btn-sm'>Edit</a>

<a href='delete_category.php?cat_del={$row['c_id']}'
onclick=\"return confirm('Delete this category?')\"
class='btn btn-danger btn-sm'>Delete</a>

</td>
</tr>
";

}

}

?>

</tbody>

</table>

</div>

</div>
</div>

</div>

</body>
</html>