<?php
session_start();
include("../connection/connect.php");

error_reporting(E_ALL);
ini_set('display_errors',1);

/* ================== ADMIN PROTECTION ================== */
if(!isset($_SESSION['adm_id'])){
    header("Location:index.php");
    exit();
}

$error="";
$success="";

/* ================= ADD DISH ================= */

if(isset($_POST['submit'])){

$d_name  = trim($_POST['d_name']);
$about   = trim($_POST['about']);
$price   = trim($_POST['price']);
$res_id  = trim($_POST['res_name']);

if($d_name=="" || $about=="" || $price=="" || $res_id==""){
    $error="All fields are required!";
}
else{

/* ===== IMAGE VALIDATION ===== */

if(!isset($_FILES['file']) || $_FILES['file']['error']!=0){
    $error="Please select image";
}else{

$allowed = ['jpg','jpeg','png','gif'];

$filename = $_FILES['file']['name'];
$tmp      = $_FILES['file']['tmp_name'];
$size     = $_FILES['file']['size'];

$ext = strtolower(pathinfo($filename,PATHINFO_EXTENSION));

if(!in_array($ext,$allowed)){
    $error="Only JPG, PNG, GIF allowed";
}
elseif($size > 1024*1024){
    $error="Image must be below 1MB";
}
else{

$newname = uniqid('dish_',true).".".$ext;
$upload  = "Res_img/dishes/".$newname;

/* ===== SAVE TO DATABASE ===== */

$stmt = $db->prepare("
INSERT INTO dishes(rs_id,title,slogan,price,img)
VALUES(?,?,?,?,?)
");

$stmt->bind_param(
"issds",
$res_id,
$d_name,
$about,
$price,
$newname
);

if($stmt->execute()){

move_uploaded_file($tmp,$upload);

$success="New Dish Added Successfully!";
}else{
$error="Database error while saving.";
}

}
}

}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">

<title>Add Menu - Admin</title>

<link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">

<style>

body{
background:#f4f6f9;
font-family:Segoe UI;
}

.card{
border-radius:14px;
box-shadow:0 5px 25px rgba(0,0,0,.08);
}

.card-header{
background:#ff6600;
color:#fff;
font-weight:bold;
}

.btn-primary{
background:#ff6600;
border:none;
}

.btn-primary:hover{
background:#e65c00;
}

.alert{
border-radius:10px;
}

</style>

</head>

<body>

<div class="container mt-4">

<div class="card">

<div class="card-header">
Add New Menu Item
</div>

<div class="card-body">

<?php if($error!=""){ ?>
<div class="alert alert-danger"><?php echo $error;?></div>
<?php } ?>

<?php if($success!=""){ ?>
<div class="alert alert-success"><?php echo $success;?></div>
<?php } ?>

<form method="post" enctype="multipart/form-data">

<div class="row">

<div class="col-md-6 mb-3">
<label>Dish Name</label>
<input type="text" name="d_name" class="form-control" required>
</div>

<div class="col-md-6 mb-3">
<label>Description</label>
<input type="text" name="about" class="form-control" required>
</div>

<div class="col-md-6 mb-3">
<label>Price</label>
<input type="number" step="0.01" name="price" class="form-control" required>
</div>

<div class="col-md-6 mb-3">
<label>Dish Image</label>
<input type="file" name="file" class="form-control" accept="image/*" required>
</div>

<div class="col-md-12 mb-3">
<label>Select Restaurant</label>
<select name="res_name" class="form-control" required>

<option value="">-- Select Restaurant --</option>

<?php
$res=$db->query("SELECT rs_id,title FROM restaurant ORDER BY title ASC");
while($row=$res->fetch_assoc()){
echo "<option value='{$row['rs_id']}'>{$row['title']}</option>";
}
?>

</select>
</div>

</div>

<button type="submit" name="submit" class="btn btn-primary">
Save Menu
</button>

<a href="dashboard.php" class="btn btn-secondary">
Back
</a>

</form>

</div>
</div>

</div>

</body>
</html>