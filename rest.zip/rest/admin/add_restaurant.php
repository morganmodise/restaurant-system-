<?php
session_start();
include("../connection/connect.php");

error_reporting(E_ALL);
ini_set('display_errors',1);

/* ================= ADMIN CHECK ================= */
if(!isset($_SESSION['adm_id'])){
header("Location:index.php");
exit();
}

$error="";
$success="";
$edit=false;

/* ================= EDIT LOAD ================= */

if(isset($_GET['edit'])){
$edit=true;
$id=(int)$_GET['edit'];

$stmt=$db->prepare("SELECT * FROM restaurant WHERE rs_id=?");
$stmt->bind_param("i",$id);
$stmt->execute();
$result=$stmt->get_result();
$data=$result->fetch_assoc();
}

/* ================= ADD / UPDATE ================= */

if(isset($_POST['submit'])){

$id=$_POST['id'] ?? '';

$c_id=$_POST['c_name'];
$title=trim($_POST['res_name']);
$email=$_POST['email'];
$phone=$_POST['phone'];
$url=$_POST['url'];
$o_hr=$_POST['o_hr'];
$c_hr=$_POST['c_hr'];
$o_days=$_POST['o_days'];
$address=$_POST['address'];

if(empty($title)||empty($email)||empty($phone)||empty($address)){
$error="<div class='alert alert-danger'>Fill all required fields</div>";
}
else{

$image_name="";

if(!empty($_FILES['file']['name'])){

$ext=strtolower(pathinfo($_FILES['file']['name'],PATHINFO_EXTENSION));
$allowed=['jpg','png','gif'];

if(!in_array($ext,$allowed)){
$error="<div class='alert alert-danger'>Invalid image type</div>";
}
else{

$image_name=uniqid().".".$ext;
move_uploaded_file(
$_FILES['file']['tmp_name'],
"Res_img/".$image_name
);

}
}

/* ========= UPDATE ========= */
if($id!=""){

if($image_name!=""){

$stmt=$db->prepare("UPDATE restaurant SET
c_id=?,title=?,email=?,phone=?,url=?,o_hr=?,c_hr=?,o_days=?,address=?,image=? 
WHERE rs_id=?");

$stmt->bind_param(
"isssssssssi",
$c_id,$title,$email,$phone,$url,$o_hr,$c_hr,$o_days,$address,$image_name,$id
);

}else{

$stmt=$db->prepare("UPDATE restaurant SET
c_id=?,title=?,email=?,phone=?,url=?,o_hr=?,c_hr=?,o_days=?,address=? 
WHERE rs_id=?");

$stmt->bind_param(
"issssssssi",
$c_id,$title,$email,$phone,$url,$o_hr,$c_hr,$o_days,$address,$id
);

}

$stmt->execute();
$success="<div class='alert alert-success'>Restaurant Updated</div>";

}

/* ========= INSERT ========= */
else{

$stmt=$db->prepare("INSERT INTO restaurant
(c_id,title,email,phone,url,o_hr,c_hr,o_days,address,image)
VALUES(?,?,?,?,?,?,?,?,?,?)");

$stmt->bind_param(
"isssssssss",
$c_id,$title,$email,$phone,$url,$o_hr,$c_hr,$o_days,$address,$image_name
);

$stmt->execute();

$success="<div class='alert alert-success'>Restaurant Added</div>";
}

}

}
?>
<!DOCTYPE html>
<html>
<head>

<meta name="viewport" content="width=device-width,initial-scale=1">

<title>Restaurant Manager</title>

<link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">

<style>

body{
background:#f5f6fa;
font-family:Segoe UI;
}

.card{
border-radius:15px;
box-shadow:0 6px 20px rgba(0,0,0,.1);
}

.card-header{
background:#ff6600;
color:#fff;
font-weight:bold;
}

.btn-primary{
background:#ff6600;
border:none;
}

.btn-primary:hover{
background:#e65c00;
}

table{
background:white;
}

img{
border-radius:8px;
}

</style>
</head>

<body>

<div class="container mt-4">

<h3>🍔 Restaurant Manager</h3>

<?= $error ?>
<?= $success ?>

<div class="card mb-4">

<div class="card-header">
<?= $edit ? "Update Restaurant" : "Add Restaurant" ?>
</div>

<div class="card-body">

<form method="post" enctype="multipart/form-data">

<input type="hidden" name="id"
value="<?= $data['rs_id'] ?? '' ?>">

<div class="row">

<div class="col-md-6 mb-3">
<label>Name</label>
<input name="res_name" class="form-control"
value="<?= $data['title'] ?? '' ?>">
</div>

<div class="col-md-6 mb-3">
<label>Email</label>
<input name="email" class="form-control"
value="<?= $data['email'] ?? '' ?>">
</div>

<div class="col-md-6 mb-3">
<label>Phone</label>
<input name="phone" class="form-control"
value="<?= $data['phone'] ?? '' ?>">
</div>

<div class="col-md-6 mb-3">
<label>Website</label>
<input name="url" class="form-control"
value="<?= $data['url'] ?? '' ?>">
</div>

<div class="col-md-6 mb-3">
<label>Category</label>
<select name="c_name" class="form-control">

<?php
$res=$db->query("SELECT * FROM res_category");
while($row=$res->fetch_assoc()){
$selected=($data['c_id']??'')==$row['c_id']?"selected":"";
echo "<option value='{$row['c_id']}' $selected>{$row['c_name']}</option>";
}
?>

</select>
</div>

<div class="col-md-6 mb-3">
<label>Image</label>
<input type="file" name="file" class="form-control">
</div>

<div class="col-md-12 mb-3">
<label>Address</label>
<textarea name="address" class="form-control"><?= $data['address'] ?? '' ?></textarea>
</div>

</div>

<button class="btn btn-primary" name="submit">
<?= $edit ? "Update Restaurant" : "Add Restaurant" ?>
</button>

</form>

</div>
</div>

<!-- ================= RESTAURANT LIST ================= -->

<div class="card">

<div class="card-header">All Restaurants</div>

<div class="card-body">

<div class="table-responsive">

<table class="table table-bordered table-hover">

<tr>
<th>ID</th>
<th>Name</th>
<th>Phone</th>
<th>Image</th>
<th>Action</th>
</tr>

<?php
$q=$db->query("SELECT * FROM restaurant ORDER BY rs_id DESC");

while($r=$q->fetch_assoc()){
echo "
<tr>
<td>{$r['rs_id']}</td>
<td>{$r['title']}</td>
<td>{$r['phone']}</td>
<td><img src='Res_img/{$r['image']}' width='60'></td>
<td>
<a href='add_restaurant.php?edit={$r['rs_id']}'
class='btn btn-info btn-sm'>Edit</a>
</td>
</tr>";
}
?>

</table>

</div>
</div>
</div>

</div>

</body>
</html>