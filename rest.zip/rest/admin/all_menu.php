<?php
session_start();

/* ================= SHOW ERRORS ================= */
error_reporting(E_ALL);
ini_set('display_errors',1);

/* ================= DB CONNECTION ================= */
include("../connection/connect.php");

if(!$db){
    die("Database connection failed.");
}

/* ================= ADMIN PROTECTION ================= */
if(!isset($_SESSION['adm_id'])){
    header("Location:index.php");
    exit();
}

/* ================= FETCH MENU ================= */
/* PERFORMANCE FIX: JOIN instead of query inside loop */

$sql = "
SELECT dishes.*, restaurant.title AS restaurant_name
FROM dishes
LEFT JOIN restaurant
ON dishes.rs_id = restaurant.rs_id
ORDER BY dishes.d_id DESC
";

$query = mysqli_query($db,$sql);

if(!$query){
    die("Query Failed: ".mysqli_error($db));
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">

<title>All Menu</title>

<link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">

<style>

body{
background:#f4f6f9;
font-family:Segoe UI;
}

.card{
border-radius:14px;
box-shadow:0 5px 25px rgba(0,0,0,.08);
}

.card-header{
background:#ff6600;
color:#fff;
font-weight:bold;
}

.table img{
border-radius:10px;
}

.navbar{
background:#fff;
box-shadow:0 2px 8px rgba(0,0,0,.08);
}

@media(max-width:768px){
table{
font-size:12px;
}
}

</style>

</head>

<body>

<!-- ================= TOP BAR ================= -->

<nav class="navbar navbar-expand-lg">

<div class="container-fluid">

<a class="navbar-brand" href="dashboard.php">
<img src="images/icn.png" width="40">
</a>

<div class="ml-auto">
<a href="dashboard.php" class="btn btn-dark btn-sm">Dashboard</a>
<a href="add_menu.php" class="btn btn-success btn-sm">+ Add Menu</a>
<a href="logout.php" class="btn btn-danger btn-sm">Logout</a>
</div>

</div>

</nav>


<div class="container-fluid mt-4">

<div class="card">

<div class="card-header">
🍔 All Menu Items
</div>

<div class="card-body table-responsive">

<table class="table table-hover table-bordered">

<thead class="thead-dark">

<tr>
<th>Restaurant</th>
<th>Dish</th>
<th>Description</th>
<th>Price</th>
<th>Image</th>
<th>Action</th>
</tr>

</thead>

<tbody>

<?php

if(mysqli_num_rows($query)==0){
echo "<tr><td colspan='6' class='text-center'>No Menu Found</td></tr>";
}
else{

while($row=mysqli_fetch_assoc($query)){
?>

<tr>

<td><?= htmlspecialchars($row['restaurant_name']) ?></td>

<td><?= htmlspecialchars($row['title']) ?></td>

<td><?= htmlspecialchars($row['slogan']) ?></td>

<td><b>R<?= number_format($row['price'],2) ?></b></td>

<td>
<img src="Res_img/dishes/<?= $row['img'] ?>"
width="120">
</td>

<td>

<a href="update_menu.php?menu_upd=<?= $row['d_id'] ?>"
class="btn btn-info btn-sm">
Edit
</a>

<a href="delete_menu.php?menu_del=<?= $row['d_id'] ?>"
onclick="return confirm('Delete this menu item?')"
class="btn btn-danger btn-sm">
Delete
</a>

</td>

</tr>

<?php
}
}
?>

</tbody>

</table>

</div>
</div>

</div>

<script src="js/lib/jquery/jquery.min.js"></script>
<script src="js/lib/bootstrap/js/bootstrap.min.js"></script>

</body>
</html>