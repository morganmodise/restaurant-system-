<?php
include("../connection/connect.php");
error_reporting(0);
session_start();

/* ---------------- STATUS UPDATE ---------------- */
if(isset($_GET['status']) && isset($_GET['o_id'])) {

    $status = mysqli_real_escape_string($db, $_GET['status']);
    $order_id = intval($_GET['o_id']);

    if($status == 'dispatch') $new_status = 'in process';
    elseif($status == 'delivered') $new_status = 'closed';
    elseif($status == 'cancel') $new_status = 'rejected';
    else $new_status = $status;

    $update = "UPDATE users_orders SET status='$new_status' WHERE o_id='$order_id'";
    mysqli_query($db, $update);

    header("Location: all_orders.php");
    exit;
}


/* ---------------- PRINT RECEIPT ---------------- */
if(isset($_GET['print']) && isset($_GET['o_id'])) {

    $order_id = intval($_GET['o_id']);

    // Fetch all items under the same order id
    $sql = "SELECT users.username, users.address, users_orders.*
            FROM users
            INNER JOIN users_orders ON users.u_id = users_orders.u_id
            WHERE users_orders.o_id = $order_id";

    $query = mysqli_query($db, $sql);

    if(mysqli_num_rows($query) > 0) {

        $items = [];
        $total = 0;
        $order_date = "";
        $username = "";
        $address = "";

        while($row = mysqli_fetch_assoc($query)) {
            $items[] = $row;
            $order_date = $row['date'];
            $username = $row['username'];
            $address = $row['address'];

            // total = price * qty
            $total += ($row['price'] * $row['quantity']);
        }
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>Receipt - Order #<?php echo $order_id; ?></title>

            <style>
                body {
                    font-family: 'Courier New', monospace;
                    margin: 0;
                    padding: 0;
                    background: #fff;
                }

                .receipt {
                    width: 380px;
                    margin: auto;
                    padding: 15px;
                    border: 2px dashed #000;
                }

                .logo {
                    text-align: center;
                    margin-bottom: 10px;
                }

                .logo img {
                    width: 140px;
                    height: auto;
                }

                h2, h3 {
                    text-align: center;
                    margin: 3px 0;
                }

                h2 {
                    font-size: 20px;
                }

                h3 {
                    font-size: 16px;
                }

                p {
                    margin: 4px 0;
                    font-size: 13px;
                }

                .line {
                    border-top: 1px dashed #000;
                    margin: 8px 0;
                }

                table {
                    width: 100%;
                    border-collapse: collapse;
                    font-size: 13px;
                }

                th, td {
                    padding: 5px 3px;
                }

                th {
                    border-bottom: 1px dashed #000;
                    text-align: left;
                }

                .total-row {
                    border-top: 1px dashed #000;
                    font-weight: bold;
                }

                .center {
                    text-align: center;
                }

                .right {
                    text-align: right;
                }

                @media print {
                    body {
                        margin: 0;
                        padding: 0;
                    }
                    .receipt {
                        border: none;
                    }
                }
            </style>
        </head>

        <body onload="window.print();">

        <div class="receipt">

            <div class="logo">
                <!-- CHANGE THIS PATH TO YOUR LOGO -->
                <img src="logo.png" alt="Logo">
            </div>

            <h2>Delicious Restaurant</h2>
            <h3>RECEIPT SLIP</h3>

            <div class="line"></div>

            <p><strong>Order No:</strong> #<?php echo $order_id; ?></p>
            <p><strong>Date:</strong> <?php echo $order_date; ?></p>
            <p><strong>Customer:</strong> <?php echo $username; ?></p>
            <p><strong>Address:</strong> <?php echo $address; ?></p>

            <div class="line"></div>

            <table>
                <tr>
                    <th>Item</th>
                    <th class="center">Qty</th>
                    <th class="right">Price</th>
                    <th class="right">Total</th>
                </tr>

                <?php foreach($items as $it): 
                    $item_total = $it['price'] * $it['quantity'];
                ?>
                <tr>
                    <td><?php echo $it['title']; ?></td>
                    <td class="center"><?php echo $it['quantity']; ?></td>
                    <td class="right">R<?php echo number_format($it['price'], 2); ?></td>
                    <td class="right">R<?php echo number_format($item_total, 2); ?></td>
                </tr>
                <?php endforeach; ?>

                <tr class="total-row">
                    <td colspan="3" class="right">TOTAL:</td>
                    <td class="right">R<?php echo number_format($total, 2); ?></td>
                </tr>
            </table>

            <div class="line"></div>

            <p class="center"><strong>THANK YOU FOR YOUR ORDER!</strong></p>
            <p class="center">Powered by Ekse Player</p>

        </div>

        </body>
        </html>
        <?php
    } else {
        echo "Order not found!";
    }
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>All Orders</title>

<link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">
<link href="css/helper.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">

<style>
body {
    background-color: #1e1e1e;
    color: #ffb347;
}
.card-outline-primary {
    border: 2px solid #ff6700;
    box-shadow: 0 0 20px #ff6700;
}
.card-header {
    background: #ff6700;
    color: #fff;
    text-shadow: 0 0 10px #ff9c33;
}
.table thead th {
    background: #ff6700;
    color: #fff;
    text-shadow: 0 0 5px #ff9c33;
}
.btn-orange {
    background-color: #ff6700;
    border: 1px solid #ff9c33;
    color: #fff;
    text-shadow: 0 0 5px #fff;
    box-shadow: 0 0 10px #ff9c33;
    transition: all 0.3s ease;
}
.btn-orange:hover {
    box-shadow: 0 0 20px #ff9c33, 0 0 40px #ff9c33;
}
marquee a {
    color: #ffb347;
    font-weight: bold;
}
</style>

</head>

<body class="fix-header fix-sidebar">

<div id="main-wrapper">

<div class="page-wrapper">
    <div style="padding-top: 10px;">
        <marquee onMouseOver="this.stop()" onMouseOut="this.start()">
            <a href="https://www.youtube.com/@codecampbdofficial">Code Camp BD and Ekse Player</a> are the owners of this script...
        </marquee>
    </div>
    
<div style="margin-bottom: 15px;">
    <a href="dashboard.php" class="btn btn-orange btn-lg">
        <i class="fa fa-tachometer"></i> Dashboard Action
    </a>
</div>
    
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="col-lg-12">
                    <div class="card card-outline-primary">
                        <div class="card-header">
                            <h4 class="m-b-0 text-white">All Orders</h4>
                        </div>

                        <div class="table-responsive m-t-40">
                            <table id="myTable" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>Order No</th>
                                        <th>User</th>
                                        <th>Title</th>
                                        <th>Quantity</th>
                                        <th>Price</th>
                                        <th>Address</th>
                                        <th>Status</th>
                                        <th>Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tbody>
                                <?php
                                // Show latest orders first
                                $sql="SELECT users.*, users_orders.* 
                                      FROM users 
                                      INNER JOIN users_orders ON users.u_id = users_orders.u_id
                                      ORDER BY users_orders.o_id DESC";

                                $query=mysqli_query($db,$sql);

                                if(!mysqli_num_rows($query) > 0) {
                                    echo '<tr><td colspan="9"><center>No Orders</center></td></tr>';
                                } else {

                                    while($rows=mysqli_fetch_array($query)) {

                                        echo '<tr>
                                            <td>#'.$rows['o_id'].'</td>
                                            <td>'.$rows['username'].'</td>
                                            <td>'.$rows['title'].'</td>
                                            <td>'.$rows['quantity'].'</td>
                                            <td>R'.number_format($rows['price'],2).'</td>
                                            <td>'.$rows['address'].'</td>
                                            <td>';

                                        $status=$rows['status'];

                                        if($status=="" || $status=="NULL") {
                                            echo '<a href="?status=dispatch&o_id='.$rows['o_id'].'" class="btn btn-orange btn-sm">
                                                    Dispatch
                                                  </a>';
                                        } elseif($status=="in process") {
                                            echo '<a href="?status=delivered&o_id='.$rows['o_id'].'" class="btn btn-orange btn-sm">
                                                    On The Way
                                                  </a>';
                                        } elseif($status=="closed") {
                                            echo '<button class="btn btn-orange btn-sm">Delivered</button>';
                                        } elseif($status=="rejected") {
                                            echo '<button class="btn btn-orange btn-sm">Cancelled</button>';
                                        }

                                        echo '</td>
                                            <td>'.$rows['date'].'</td>
                                            <td>
                                                <a href="delete_orders.php?order_del='.$rows['o_id'].'" onclick="return confirm(\'Are you sure?\');" class="btn btn-orange btn-xs m-b-10">
                                                    <i class="fa fa-trash-o"></i>
                                                </a>

                                                <a href="view_order.php?user_upd='.$rows['o_id'].'" class="btn btn-orange btn-xs m-b-10">
                                                    <i class="fa fa-edit"></i>
                                                </a>

                                                <a href="?print=1&o_id='.$rows['o_id'].'" target="_blank" class="btn btn-orange btn-xs m-b-10">
                                                    <i class="fa fa-print"></i> Print
                                                </a>
                                            </td>
                                        </tr>';
                                    }
                                }
                                ?>
                                </tbody>

                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include "include/footer.php"; ?>

</div>
</div>

<script src="js/lib/jquery/jquery.min.js"></script>
<script src="js/lib/bootstrap/js/popper.min.js"></script>
<script src="js/lib/bootstrap/js/bootstrap.min.js"></script>
<script src="js/custom.min.js"></script>

</body>
</html>