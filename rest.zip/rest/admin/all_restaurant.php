<?php
session_start();

/* ================= SHOW ERRORS ================= */
error_reporting(E_ALL);
ini_set('display_errors',1);

/* ================= DB CONNECT ================= */
include("../connection/connect.php");

if(!isset($db)){
    die("Database connection failed.");
}

/* ================= ADMIN PROTECTION ================= */
if(!isset($_SESSION['adm_id'])){
    header("Location:index.php");
    exit();
}

/* ================= FETCH RESTAURANTS ================= */
$sql = "
SELECT restaurant.*, res_category.c_name
FROM restaurant
LEFT JOIN res_category
ON restaurant.c_id = res_category.c_id
ORDER BY restaurant.rs_id DESC
";

$result = mysqli_query($db,$sql);

if(!$result){
    die("Query Error: ".mysqli_error($db));
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">

<title>All Restaurants</title>

<link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">

<style>
body{
background:#f4f6f9;
font-family:Segoe UI;
}

.card{
border-radius:14px;
box-shadow:0 5px 20px rgba(0,0,0,.08);
}

.card-header{
background:#ff6600;
color:#fff;
font-weight:bold;
}

.table img{
border-radius:10px;
}

@media(max-width:768px){
table{
font-size:12px;
}
}
</style>

</head>

<body>

<div class="container-fluid mt-4">

<div class="d-flex justify-content-between mb-3">
<h3>🍔 All Restaurants</h3>

<div>
<a href="dashboard.php" class="btn btn-dark">Dashboard</a>
<a href="add_restaurant.php" class="btn btn-success">+ Add Restaurant</a>
<a href="logout.php" class="btn btn-danger">Logout</a>
</div>
</div>

<div class="card">

<div class="card-header">
Restaurant List
</div>

<div class="card-body table-responsive">

<table class="table table-bordered table-hover">

<thead class="thead-dark">
<tr>
<th>Category</th>
<th>Name</th>
<th>Email</th>
<th>Phone</th>
<th>Website</th>
<th>Open</th>
<th>Close</th>
<th>Days</th>
<th>Address</th>
<th>Image</th>
<th>Date</th>
<th>Action</th>
</tr>
</thead>

<tbody>

<?php
if(mysqli_num_rows($result)==0){
echo "<tr><td colspan='12' class='text-center'>No Restaurants Found</td></tr>";
}else{

while($row=mysqli_fetch_assoc($result)){
?>

<tr>

<td><?= htmlspecialchars($row['c_name']) ?></td>
<td><?= htmlspecialchars($row['title']) ?></td>
<td><?= htmlspecialchars($row['email']) ?></td>
<td><?= htmlspecialchars($row['phone']) ?></td>

<td>
<a href="<?= htmlspecialchars($row['url']) ?>" target="_blank">
Visit
</a>
</td>

<td><?= $row['o_hr'] ?></td>
<td><?= $row['c_hr'] ?></td>
<td><?= $row['o_days'] ?></td>

<td><?= htmlspecialchars($row['address']) ?></td>

<td>
<img src="Res_img/<?= $row['image'] ?>" width="120">
</td>

<td><?= $row['date'] ?></td>

<td>

<a href="update_restaurant.php?res_upd=<?= $row['rs_id'] ?>"
class="btn btn-info btn-sm">
Edit
</a>

<a href="delete_restaurant.php?res_del=<?= $row['rs_id'] ?>"
onclick="return confirm('Delete this restaurant?')"
class="btn btn-danger btn-sm">
Delete
</a>

</td>

</tr>

<?php
}
}
?>

</tbody>

</table>

</div>
</div>

</div>

<script src="js/lib/jquery/jquery.min.js"></script>
<script src="css/lib/bootstrap/js/bootstrap.min.js"></script>

</body>
</html>