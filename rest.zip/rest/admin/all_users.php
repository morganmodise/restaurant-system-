<?php
session_start();

/* ================= SHOW ERRORS ================= */
error_reporting(E_ALL);
ini_set('display_errors',1);

/* ================= DB CONNECT ================= */
include("../connection/connect.php");

if(!isset($db)){
    die("Database connection failed.");
}

/* ================= ADMIN PROTECTION ================= */
if(!isset($_SESSION['adm_id'])){
    header("Location:index.php");
    exit();
}

/* ================= FETCH USERS ================= */
$sql = "SELECT * FROM users ORDER BY u_id DESC";
$result = mysqli_query($db,$sql);

if(!$result){
    die("Query Failed: ".mysqli_error($db));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">

<title>Admin - All Users</title>

<link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">
<link href="css/helper.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">

<style>
body{
background:#f4f6f9;
font-family:Segoe UI;
}
.card-header{
background:#ff6600;
color:#fff;
}
</style>

</head>

<body class="fix-header fix-sidebar">

<div id="main-wrapper">

<!-- ================= TOP NAV ================= -->
<div class="header">
<nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">

<a class="navbar-brand" href="dashboard.php">
<img src="images/icn.png" height="35">
</a>

<ul class="navbar-nav ml-auto">
<li class="nav-item">
<a href="logout.php" class="btn btn-danger btn-sm">Logout</a>
</li>
</ul>

</nav>
</div>

<!-- ================= SIDEBAR ================= -->
<div class="left-sidebar">
<div class="scroll-sidebar">

<nav class="sidebar-nav">
<ul id="sidebarnav">

<li><a href="dashboard.php">Dashboard</a></li>
<li><a href="all_users.php">Users</a></li>

<li>Restaurant
<ul>
<li><a href="all_restaurant.php">All Restaurants</a></li>
<li><a href="add_category.php">Add Category</a></li>
<li><a href="add_restaurant.php">Add Restaurant</a></li>
</ul>
</li>

<li>Menu
<ul>
<li><a href="all_menu.php">All Menu</a></li>
<li><a href="add_menu.php">Add Menu</a></li>
</ul>
</li>

<li><a href="all_orders.php">Orders</a></li>

</ul>
</nav>

</div>
</div>

<!-- ================= PAGE CONTENT ================= -->
<div class="page-wrapper">

<div class="container-fluid mt-4">

<div class="card">

<div class="card-header">
<h4>All Users</h4>
</div>

<div class="card-body">

<div class="table-responsive">

<table class="table table-bordered table-hover">

<thead class="thead-dark">
<tr>
<th>Username</th>
<th>First Name</th>
<th>Last Name</th>
<th>Email</th>
<th>Phone</th>
<th>Address</th>
<th>Reg Date</th>
<th>Action</th>
</tr>
</thead>

<tbody>

<?php
if(mysqli_num_rows($result) == 0){
echo "<tr><td colspan='8' class='text-center'>No Users Found</td></tr>";
}else{

while($row = mysqli_fetch_assoc($result)){
?>

<tr>
<td><?= htmlspecialchars($row['username']) ?></td>
<td><?= htmlspecialchars($row['f_name']) ?></td>
<td><?= htmlspecialchars($row['l_name']) ?></td>
<td><?= htmlspecialchars($row['email']) ?></td>
<td><?= htmlspecialchars($row['phone']) ?></td>
<td><?= htmlspecialchars($row['address']) ?></td>
<td><?= htmlspecialchars($row['date']) ?></td>

<td>

<a href="update_users.php?user_upd=<?= $row['u_id'] ?>"
class="btn btn-info btn-sm">
Edit
</a>

<a href="delete_users.php?user_del=<?= $row['u_id'] ?>"
onclick="return confirm('Delete this user?')"
class="btn btn-danger btn-sm">
Delete
</a>

</td>
</tr>

<?php
}
}
?>

</tbody>
</table>

</div>

</div>
</div>

</div>
</div>

</div>

<!-- ================= SCRIPTS ================= -->
<script src="js/lib/jquery/jquery.min.js"></script>
<script src="js/lib/bootstrap/js/popper.min.js"></script>
<script src="js/lib/bootstrap/js/bootstrap.min.js"></script>

</body>
</html>