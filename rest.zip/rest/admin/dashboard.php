<?php
session_start();
include("../connection/connect.php");

error_reporting(E_ALL);
ini_set('display_errors',1);

/* ========= PROTECT PAGE ========= */
if(!isset($_SESSION['adm_id'])){
header("Location: index.php");
exit();
}

/* ========= COUNTS ========= */
$users = mysqli_num_rows(mysqli_query($db,"SELECT * FROM users"));
$orders = mysqli_num_rows(mysqli_query($db,"SELECT * FROM users_orders"));
$restaurants = mysqli_num_rows(mysqli_query($db,"SELECT * FROM restaurant"));
$pending = mysqli_num_rows(mysqli_query($db,"SELECT * FROM users_orders WHERE status IS NULL"));
?>

<!DOCTYPE html>
<html>
<head>

<title>Admin Dashboard</title>
<meta name="viewport" content="width=device-width,initial-scale=1">

<style>

body{
margin:0;
font-family:Arial;
background:#111;
color:#fff;
}

/* ===== SIDEBAR ===== */

.sidebar{
width:230px;
height:100vh;
background:#000;
position:fixed;
padding-top:20px;
}

.sidebar h2{
text-align:center;
color:#ff6600;
}

.sidebar a{
display:block;
padding:15px;
color:#fff;
text-decoration:none;
border-bottom:1px solid #222;
}

.sidebar a:hover{
background:#ff6600;
}

/* ===== CONTENT ===== */

.content{
margin-left:230px;
padding:25px;
}

.card{
background:#1c1c1c;
padding:25px;
margin:15px;
border-radius:10px;
display:inline-block;
width:220px;
text-align:center;
box-shadow:0 0 10px rgba(0,0,0,.6);
}

.card h1{
color:#ff6600;
margin:10px 0;
}

.topbar{
background:#000;
padding:15px;
text-align:right;
}

.logout{
background:red;
padding:8px 15px;
color:#fff;
text-decoration:none;
border-radius:6px;
}

</style>

</head>

<body>

<!-- ===== SIDEBAR ===== -->

<div class="sidebar">

<h2>ADMIN PANEL</h2>

<a href="dashboard.php">🏠 Dashboard</a>

<a href="all_users.php">👥 Users</a>

<a href="all_orders.php">🧾 Orders</a>

<a href="all_restaurant.php">🍴 Restaurants</a>

<a href="add_restaurant.php">➕ Add Restaurant</a>

<a href="all_menu.php">🍔 Menu Items</a>

<a href="reports.php">📊 Reports</a>

<a href="settings.php">⚙ Settings</a>

<a href="logout.php">🚪 Logout</a>

</div>

<!-- ===== CONTENT ===== -->

<div class="content">

<div class="topbar">
Welcome Admin |
<a class="logout" href="logout.php">Logout</a>
</div>

<h1>Dashboard Overview</h1>

<div class="card">
<h3>Total Users</h3>
<h1><?php echo $users; ?></h1>
</div>

<div class="card">
<h3>Total Orders</h3>
<h1><?php echo $orders; ?></h1>
</div>

<div class="card">
<h3>Restaurants</h3>
<h1><?php echo $restaurants; ?></h1>
</div>

<div class="card">
<h3>Pending Orders</h3>
<h1><?php echo $pending; ?></h1>
</div>

</div>

</body>
</html>