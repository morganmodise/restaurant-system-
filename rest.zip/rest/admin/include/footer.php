 <footer class="footer" style="text-align: center;">Code Camp BD & Ekse Player © 2026 - Online Food Ordering System Developer - <a href="https://www.facebook.com/dev.mhrony">MH RONY & Morgan Modise</a> </footer>
 <!--/*!
 * Author Name: MH RONY & Morgan Modise.
 * GigHub Link: https://github.com/dev-mhrony
 * GigHub Link: https://github.com/morgan-modise
 * Facebook Link:https://www.facebook.com/dev.mhrony
 * Youtube Link: https://www.youtube.com/channel/UChYhUxkwDNialcxj-OFRcDw
 for any PHP, Laravel, Python, Dart, Flutter work contact me at developer.mhrony@gmail.com
 * Visit My Website : developerrony.com

 */ -->