<?php
session_start();
include("../connection/connect.php");

error_reporting(E_ALL);
ini_set('display_errors',1);

/* ================= ALREADY LOGGED IN ================= */
if(isset($_SESSION['adm_id'])){
header("Location: dashboard.php");
exit();
}

$error="";

/* ================= LOGIN ================= */
if(isset($_POST['submit'])){

$username = trim($_POST['username']);
$password = trim($_POST['password']);

if($username=="" || $password==""){
$error="All fields required!";
}
else{

$stmt = $db->prepare("SELECT * FROM admin WHERE username=? LIMIT 1");
$stmt->bind_param("s",$username);
$stmt->execute();

$result = $stmt->get_result();

if($result->num_rows>0){

$admin = $result->fetch_assoc();

/* SUPPORT OLD MD5 + NEW HASH */
if(
password_verify($password,$admin['password'])
|| md5($password)==$admin['password']
){

$_SESSION['adm_id']=$admin['adm_id'];

header("Location: dashboard.php");
exit();

}else{
$error="Invalid Username or Password";
}

}else{
$error="Invalid Username or Password";
}

}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">

<title>Admin Login</title>

<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700" rel="stylesheet">

<style>

body{
margin:0;
background:linear-gradient(135deg,#000,#ff6600);
font-family:Roboto;
height:100vh;
display:flex;
justify-content:center;
align-items:center;
}

.login-box{
background:#fff;
padding:40px;
border-radius:12px;
width:350px;
box-shadow:0 10px 30px rgba(0,0,0,.3);
text-align:center;
}

.login-box img{
width:90px;
margin-bottom:15px;
}

.login-box h2{
margin-bottom:20px;
}

input{
width:100%;
padding:12px;
margin:10px 0;
border-radius:6px;
border:1px solid #ddd;
font-size:15px;
}

button{
width:100%;
padding:12px;
background:#ff6600;
color:#fff;
border:none;
border-radius:6px;
font-size:16px;
cursor:pointer;
}

button:hover{
background:#e65c00;
}

.error{
color:red;
margin-bottom:10px;
}

</style>

</head>

<body>

<div class="login-box">

<img src="images/manager.png">

<h2>Admin Panel Login</h2>

<?php if($error!=""){ ?>
<div class="error"><?php echo $error; ?></div>
<?php } ?>

<form method="post">

<input type="text" name="username" placeholder="Username" required>

<input type="password" name="password" placeholder="Password" required>

<button type="submit" name="submit">Login</button>

</form>

</div>

</body>
</html>