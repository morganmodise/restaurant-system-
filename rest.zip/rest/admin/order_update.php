<?php
session_start();
include("../connection/connect.php");

error_reporting(E_ALL);
ini_set('display_errors',1);

/* ================= LOGIN CHECK ================= */
if(empty($_SESSION['user_id'])){
header("Location:../login.php");
exit();
}

/* ================= VALID ORDER ================= */
if(!isset($_GET['form_id']) || !is_numeric($_GET['form_id'])){
die("Invalid Order");
}

$form_id = (int)$_GET['form_id'];

$success="";
$error="";

/* ================= UPDATE ORDER ================= */
if(isset($_POST['update'])){

$status = trim($_POST['status']);
$remark = trim($_POST['remark']);

if($status=="" || $remark==""){
$error="Fill all fields";
}
else{

/* insert remark */
$stmt1 = $db->prepare(
"INSERT INTO remark(frm_id,status,remark)
VALUES(?,?,?)"
);

$stmt1->bind_param("iss",$form_id,$status,$remark);
$stmt1->execute();

/* update order */
$stmt2 = $db->prepare(
"UPDATE users_orders SET status=? WHERE o_id=?"
);

$stmt2->bind_param("si",$status,$form_id);
$stmt2->execute();

$success="Order Updated Successfully";
}
}
?>

<!DOCTYPE html>
<html>
<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">

<title>Update Order</title>

<link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">

<style>

body{
background:#f5f6fa;
font-family:Segoe UI;
}

.card{
margin-top:40px;
border-radius:15px;
box-shadow:0 5px 20px rgba(0,0,0,.15);
}

.card-header{
background:#ff6600;
color:white;
font-weight:bold;
}

.btn-primary{
background:#ff6600;
border:none;
}

.btn-primary:hover{
background:#e65c00;
}

</style>

<script>
function closeWindow(){
window.close();
}

function printPage(){
window.print();
}
</script>

</head>

<body>

<div class="container">

<div class="card">

<div class="card-header">
🍔 Update Order #<?php echo $form_id; ?>
</div>

<div class="card-body">

<?php if($error!=""){ ?>
<div class="alert alert-danger"><?php echo $error; ?></div>
<?php } ?>

<?php if($success!=""){ ?>
<div class="alert alert-success"><?php echo $success; ?></div>
<?php } ?>

<form method="post">

<div class="form-group">
<label>Status</label>

<select name="status" class="form-control" required>

<option value="">Select Status</option>
<option value="in process">🚚 On The Way</option>
<option value="closed">✅ Delivered</option>
<option value="rejected">❌ Cancelled</option>

</select>
</div>

<div class="form-group">
<label>Admin Message</label>

<textarea name="remark"
class="form-control"
rows="5"
required></textarea>

</div>

<button name="update" class="btn btn-primary">
Update Order
</button>

<button type="button"
onclick="closeWindow()"
class="btn btn-danger">
Close Window
</button>

<button type="button"
onclick="printPage()"
class="btn btn-secondary">
Print
</button>

</form>

</div>
</div>

</div>

</body>
</html>