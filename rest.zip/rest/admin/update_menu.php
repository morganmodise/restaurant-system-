<?php
include("../connection/connect.php");
session_start();
error_reporting(E_ALL);

if(empty($_SESSION["adm_id"])) {
    header('location:index.php');
    exit();
}

$error = $success = "";

// Handle form submission
if(isset($_POST['submit'])) {
    $dish_name = trim($_POST['d_name']);
    $about = trim($_POST['about']);
    $price = trim($_POST['price']);
    $res_id = $_POST['res_name'];

    if(empty($dish_name) || empty($about) || $price === '' || $res_id === '') {
        $error = '<div class="alert alert-danger">All fields must be filled!</div>';
    } else {
        $file_name = $_FILES['file']['name'];
        $temp = $_FILES['file']['tmp_name'];
        $fsize = $_FILES['file']['size'];
        $extension = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $fnew = uniqid().'.'.$extension;
        $store = "Res_img/dishes/".basename($fnew);

        if($file_name && !in_array($extension, ['jpg','png','gif'])) {
            $error = '<div class="alert alert-danger">Only JPG, PNG, GIF files allowed!</div>';
        } elseif($fsize >= 1000000) {
            $error = '<div class="alert alert-danger">Max Image Size is 1024kb!</div>';
        } else {
            $update_sql = "UPDATE dishes SET 
                rs_id='$res_id', 
                title='$dish_name', 
                slogan='$about', 
                price='$price'";

            if($file_name) {
                $update_sql .= ", img='$fnew'";
            }

            $update_sql .= " WHERE d_id='".$_GET['menu_upd']."'";

            if(mysqli_query($db, $update_sql)) {
                if($file_name) move_uploaded_file($temp, $store);
                $success = '<div class="alert alert-success">Dish updated successfully!</div>';
                // Optional: redirect to dashboard after 2s
                // header("refresh:2; url=dashboard.php");
            } else {
                $error = '<div class="alert alert-danger">Failed to update dish. Try again.</div>';
            }
        }
    }
}

// Fetch dish details
$dish_id = $_GET['menu_upd'];
$qml = "SELECT * FROM dishes WHERE d_id='$dish_id'";
$rest = mysqli_query($db, $qml);
$roww = mysqli_fetch_assoc($rest);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Update Menu</title>
<link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">
<link href="css/helper.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
</head>

<body class="fix-header">
<div id="main-wrapper">

<!-- Header -->
<div class="header">
<nav class="navbar top-navbar navbar-expand-md navbar-light">
    <div class="navbar-header">
        <a class="navbar-brand" href="dashboard.php">
            <span><img src="images/icn.png" alt="homepage" class="dark-logo" /></span>
        </a>
    </div>
    <div class="navbar-collapse">
        <ul class="navbar-nav me-auto"></ul>
        <ul class="navbar-nav my-lg-0">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle text-muted" href="#" data-toggle="dropdown">
                    <img src="images/bookingSystem/user-icn.png" alt="user" class="profile-pic" />
                </a>
                <div class="dropdown-menu dropdown-menu-right animated zoomIn">
                    <ul class="dropdown-user">
                        <li><a href="logout.php"><i class="fa fa-power-off"></i> Logout</a></li>
                    </ul>
                </div>
            </li>
        </ul>
    </div>
</nav>
</div>

<!-- Sidebar -->
<div class="left-sidebar">
<div class="scroll-sidebar">
<nav class="sidebar-nav">
    <ul id="sidebarnav">
        <li class="nav-devider"></li>
        <li class="nav-label">Home</li>
        <li><a href="dashboard.php"><i class="fa fa-tachometer"></i> Dashboard</a></li>
        <li><a href="all_users.php"><i class="fa fa-user"></i> Users</a></li>
        <li><a class="has-arrow" href="#"><i class="fa fa-archive"></i> Restaurant</a>
            <ul class="collapse">
                <li><a href="all_restaurant.php">All Restaurants</a></li>
                <li><a href="add_category.php">Add Category</a></li>
                <li><a href="add_restaurant.php">Add Restaurant</a></li>
            </ul>
        </li>
        <li><a class="has-arrow" href="#"><i class="fa fa-cutlery"></i> Menu</a>
            <ul class="collapse">
                <li><a href="all_menu.php">All Menus</a></li>
                <li><a href="add_menu.php">Add Menu</a></li>
            </ul>
        </li>
        <li><a href="all_orders.php"><i class="fa fa-shopping-cart"></i> Orders</a></li>
    </ul>
</nav>
</div>
</div>

<!-- Page wrapper -->
<div class="page-wrapper">
<div class="container-fluid">
<?php echo $error; echo $success; ?>

<div class="col-lg-12">
    <div class="card card-outline-primary">
        <div class="card-header">
            <h4 class="m-b-0 text-white">Update Dish</h4>
        </div>
        <div class="card-body">
            <form action="" method="post" enctype="multipart/form-data">
                <div class="form-body">
                    <hr>
                    <div class="row p-t-20">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Dish Name</label>
                                <input type="text" name="d_name" value="<?php echo $roww['title']; ?>" class="form-control" placeholder="Morzirella">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>About</label>
                                <input type="text" name="about" value="<?php echo $roww['slogan']; ?>" class="form-control" placeholder="Slogan">
                            </div>
                        </div>
                    </div>

                    <div class="row p-t-20">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Price</label>
                                <input type="text" name="price" value="<?php echo $roww['price']; ?>" class="form-control" placeholder="$">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Image</label>
                                <input type="file" name="file" class="form-control">
                            </div>
                        </div>
                    </div>

                    <div class="row p-t-20">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Select Restaurant</label>
                                <select name="res_name" class="form-control">
                                    <option value="">--Select Restaurant--</option>
                                    <?php 
                                    $ssql ="SELECT * FROM restaurant";
                                    $res = mysqli_query($db, $ssql); 
                                    while($row=mysqli_fetch_assoc($res)) {
                                        $selected = ($row['rs_id']==$roww['rs_id']) ? 'selected' : '';
                                        echo '<option value="'.$row['rs_id'].'" '.$selected.'>'.$row['title'].'</option>';
                                    }  
                                    ?>
                                </select>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="form-actions">
                    <input type="submit" name="submit" class="btn btn-primary" value="Save">
                    <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
                </div>
            </form>
        </div>
    </div>
</div>

</div>
</div>

<?php include "include/footer.php" ?>

<script src="js/lib/jquery/jquery.min.js"></script>
<script src="js/lib/bootstrap/js/popper.min.js"></script>
<script src="js/lib/bootstrap/js/bootstrap.min.js"></script>
<script src="js/jquery.slimscroll.js"></script>
<script src="js/sidebarmenu.js"></script>
<script src="js/lib/sticky-kit-master/dist/sticky-kit.min.js"></script>
<script src="js/custom.min.js"></script>

</body>
</html>