<?php
session_start();
include("../connection/connect.php");

// Initialize messages
$error = $success = "";

if (isset($_POST['submit'])) {

    $uname = trim($_POST['uname']);
    $fname = trim($_POST['fname']);
    $lname = trim($_POST['lname']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $password = $_POST['password']; // plain text, optional

    // Check required fields
    if (empty($uname) || empty($fname) || empty($lname) || empty($email) || empty($phone)) {
        $error = "All fields are required!";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email address!";
    } elseif (strlen($phone) < 10) {
        $error = "Phone must be at least 10 digits!";
    } elseif (!empty($password) && strlen($password) < 6) {
        $error = "Password must be at least 6 characters!";
    } else {
        // Build SQL
        if (!empty($password)) {
            $hashed = md5($password);
            $sql = "UPDATE users SET username=?, f_name=?, l_name=?, email=?, phone=?, password=? WHERE u_id=?";
            $stmt = $db->prepare($sql);
            $stmt->bind_param("ssssssi", $uname, $fname, $lname, $email, $phone, $hashed, $_GET['user_upd']);
        } else {
            $sql = "UPDATE users SET username=?, f_name=?, l_name=?, email=?, phone=? WHERE u_id=?";
            $stmt = $db->prepare($sql);
            $stmt->bind_param("sssssi", $uname, $fname, $lname, $email, $phone, $_GET['user_upd']);
        }

        if ($stmt->execute()) {
            $success = "User updated successfully!";
        } else {
            $error = "Error updating user!";
        }
        $stmt->close();
    }
}

// Fetch user data
$userData = [];
if (isset($_GET['user_upd'])) {
    $stmt = $db->prepare("SELECT * FROM users WHERE u_id=?");
    $stmt->bind_param("i", $_GET['user_upd']);
    $stmt->execute();
    $result = $stmt->get_result();
    $userData = $result->fetch_assoc();
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update User</title>
    <link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link href="css/helper.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h3>Update User</h3>

    <?php if ($error) { echo "<div class='alert alert-danger'>$error</div>"; } ?>
    <?php if ($success) { echo "<div class='alert alert-success'>$success</div>"; } ?>

    <form method="post">
        <div class="form-group">
            <label>Username</label>
            <input type="text" name="uname" class="form-control" value="<?= htmlspecialchars($userData['username'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label>First Name</label>
            <input type="text" name="fname" class="form-control" value="<?= htmlspecialchars($userData['f_name'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label>Last Name</label>
            <input type="text" name="lname" class="form-control" value="<?= htmlspecialchars($userData['l_name'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($userData['email'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label>Phone</label>
            <input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($userData['phone'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label>Password (leave blank to keep current)</label>
            <input type="password" name="password" class="form-control">
        </div>
        <input type="submit" name="submit" class="btn btn-primary" value="Save">
        <a href="all_users.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>
<script src="js/lib/jquery/jquery.min.js"></script>
<script src="js/lib/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>