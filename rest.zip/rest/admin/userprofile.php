<?php
session_start();
include("../connection/connect.php");

// Check if user is logged in
if (strlen($_SESSION['user_id']) == 0) { 
    header('location:../login.php');
    exit;
}

// Handle status/remark update
if (isset($_POST['update'])) {
    $form_id = intval($_GET['form_id']); // sanitize input
    $status = $_POST['status'];
    $remark = $_POST['remark'];

    // Use prepared statements to prevent SQL injection
    $stmt1 = $db->prepare("INSERT INTO remark(frm_id, status, remark) VALUES (?, ?, ?)");
    $stmt1->bind_param("iss", $form_id, $status, $remark);
    $stmt1->execute();
    $stmt1->close();

    $stmt2 = $db->prepare("UPDATE users_orders SET status=? WHERE o_id=?");
    $stmt2->bind_param("si", $status, $form_id);
    $stmt2->execute();
    $stmt2->close();

    echo "<script>alert('Form details updated successfully');</script>";
}

// Fetch order info
$form_id = intval($_GET['newform_id']);
$stmt = $db->prepare("
    SELECT u.f_name, u.l_name, u.email, u.phone, u.date, o.status 
    FROM users_orders o
    JOIN users u ON o.u_id = u.u_id
    WHERE o.o_id = ?
");
$stmt->bind_param("i", $form_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>User Profile</title>
<link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">
<link href="css/helper.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<script>
function closeWindow() { window.close(); }
function printPage() { window.print(); }
</script>
<style>
table { width: 650px; border-collapse: collapse; margin: 50px auto; }
tr:nth-of-type(odd) { background: #eee; }
th { background: #004684; color: white; font-weight: bold; }
td, th { padding: 10px; border: 1px solid #ccc; text-align: left; font-size: 14px; }
.btn-status { padding: 5px 10px; color: #fff; border-radius: 3px; }
.btn-active { background-color: #007bff; }
.btn-block { background-color: #dc3545; }
</style>
</head>
<body>
<div style="margin-left:50px;">
    <table>
        <tr>
            <td colspan="2"><b><?= htmlspecialchars($user['f_name']) ?>'s Profile</b></td>
        </tr>
        <tr height="50">
            <td><b>Reg Date:</b></td>
            <td><?= htmlspecialchars($user['date']) ?></td>
        </tr>
        <tr height="50">
            <td><b>First Name:</b></td>
            <td><?= htmlspecialchars($user['f_name']) ?></td>
        </tr>
        <tr height="50">
            <td><b>Last Name:</b></td>
            <td><?= htmlspecialchars($user['l_name']) ?></td>
        </tr>
        <tr height="50">
            <td><b>User Email:</b></td>
            <td><?= htmlspecialchars($user['email']) ?></td>
        </tr>
        <tr height="50">
            <td><b>User Phone:</b></td>
            <td><?= htmlspecialchars($user['phone']) ?></td>
        </tr>
        <tr height="50">
            <td><b>Status:</b></td>
            <td>
                <?php if ($user['status'] == 1): ?>
                    <span class="btn-status btn-active">Active</span>
                <?php else: ?>
                    <span class="btn-status btn-block">Blocked</span>
                <?php endif; ?>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <input type="button" class="btn btn-danger" value="Close Window" onclick="closeWindow();">
                <input type="button" class="btn btn-primary" value="Print" onclick="printPage();">
            </td>
        </tr>
    </table>
</div>
</body>
</html>