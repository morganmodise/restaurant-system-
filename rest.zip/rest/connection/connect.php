<?php

error_reporting(E_ALL);
ini_set('display_errors',1);

$servername = "sql308.infinityfree.com";
$username   = "if0_38910344";
$password   = "cXnGpYnW16";
$database   = "if0_38910344_code_camp_bd_fos";

$db = new mysqli($servername,$username,$password,$database);

if ($db->connect_error) {
    die("Database connection failed: " . $db->connect_error);
}

?>